require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  Events,
} = require("discord.js");

const token = process.env.DISCORD_BOT_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;
const guildId = process.env.DISCORD_GUILD_ID;
const cryChannelId = process.env.BABY_CHANNEL_ID;

if (!token || !clientId) {
  console.error("Missing DISCORD_BOT_TOKEN or DISCORD_CLIENT_ID in your .env file.");
  process.exit(1);
}

const commands = [
  new SlashCommandBuilder()
    .setName("feed")
    .setDescription("Feed Baby Finn."),
  new SlashCommandBuilder()
    .setName("play")
    .setDescription("Play with Baby Finn."),
  new SlashCommandBuilder()
    .setName("soothe")
    .setDescription("Soothe Baby Finn."),
].map(command => command.toJSON());

const rest = new REST({ version: "10" }).setToken(token);

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

let babyChannel = cryChannelId || null;
let isCrying = false;
let cryInterval = null;
let nextCryTimeout = null;

async function registerCommands() {
  const route = guildId
    ? Routes.applicationGuildCommands(clientId, guildId)
    : Routes.applicationCommands(clientId);

  await rest.put(route, { body: commands });
  console.log(`Registered ${commands.length} Baby Finn commands.`);
}

async function startCrying() {
  if (!babyChannel || isCrying) return;

  const channel = await client.channels.fetch(babyChannel).catch(() => null);
  if (!channel || !channel.isTextBased() || !channel.send) {
    console.error("Baby Finn's channel could not be found. Check BABY_CHANNEL_ID and permissions.");
    return;
  }

  isCrying = true;
  await channel.send("wahh... wahhh... WAHHH...");
  console.log("Baby Finn is crying.");

  // A gentle repeat interval prevents an uncontrolled message flood.
  cryInterval = setInterval(async () => {
    if (!isCrying) return;
    await channel.send("wahh... wahhh...").catch(error => {
      console.error("Could not send Baby Finn's cry:", error.message);
    });
  }, 60 * 1000);
}

function stopCrying() {
  isCrying = false;
  if (cryInterval) clearInterval(cryInterval);
  cryInterval = null;

  if (nextCryTimeout) clearTimeout(nextCryTimeout);
  nextCryTimeout = setTimeout(startCrying, 30 * 60 * 1000);
}

client.once(Events.ClientReady, async readyClient => {
  console.log(`Baby Finn is online as ${readyClient.user.tag}.`);
  try {
    await registerCommands();
  } catch (error) {
    console.error("Could not register slash commands:", error);
  }

  // The first cry happens 30 minutes after startup.
  if (babyChannel) {
    nextCryTimeout = setTimeout(startCrying, 30 * 60 * 1000);
  } else {
    console.log("No BABY_CHANNEL_ID set. Use /feed, /play, or /soothe in the channel where Finn should live.");
  }
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const responses = {
    feed: "*burps* ...mlem.",
    play: "*cooes* ...heehee!",
    soothe: "*sniffle...* *squirms* ...zzz.",
  };

  if (!responses[interaction.commandName]) return;

  if (!babyChannel) {
    babyChannel = interaction.channelId;
  }

  // Keep Finn in the channel where someone interacts with him.
  if (!cryChannelId) {
    babyChannel = interaction.channelId;
  }

  stopCrying();
  await interaction.reply({
    content: responses[interaction.commandName],
    allowedMentions: { repliedUser: false },
  });
});

client.login(token);
