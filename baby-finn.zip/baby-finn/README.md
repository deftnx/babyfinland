# Baby Finn

A tiny Discord baby bot. Baby Finn waits 30 minutes, starts crying, and keeps crying until someone uses `/feed`, `/play`, or `/soothe`.

## Commands

- `/feed` → `*burps* ...mlem.`
- `/play` → `*cooes* ...heehee!`
- `/soothe` → `*sniffle...* *squirms* ...zzz.`

Any of the three commands settles Finn and resets his 30-minute timer.

## 1. Create the Discord application

1. Open the [Discord Developer Portal](https://discord.com/developers/applications).
2. Create an application named **Baby Finn**.
3. Open **Bot** and create/reset the bot token. Keep this token private.
4. Under **OAuth2 → URL Generator**, select the `bot` and `applications.commands` scopes.
5. Invite the bot to your server with permission to **View Channels**, **Send Messages**, and **Use Application Commands**.

You do not need to enable privileged gateway intents.

## 2. Put Baby Finn in GitHub Codespaces

1. Create a GitHub repository named `baby-finn`.
2. Upload these project files to the repository.
3. Open the repository and choose **Code → Codespaces → Create codespace on main**.
4. In the Codespaces terminal, run:

   ```bash
   pnpm install
   ```

5. Make a `.env` file by copying `.env.example`:

   ```bash
   cp .env.example .env
   ```

6. Fill in `.env`:
   - `DISCORD_BOT_TOKEN`: token from the Developer Portal's Bot page.
   - `DISCORD_CLIENT_ID`: the application's **Application ID** from General Information.
   - `DISCORD_GUILD_ID`: your server ID (recommended for instant command registration).
   - `BABY_CHANNEL_ID`: optional channel ID where Finn should cry. If left blank, the first Baby Finn command chooses the channel.

To copy a Discord ID, enable Developer Mode in Discord settings, then right-click/long-press the server or channel and choose **Copy ID**.

## 3. Run him

```bash
pnpm start
```

Keep the Codespace running for Baby Finn to stay online. If you use global slash-command registration by leaving `DISCORD_GUILD_ID` blank, Discord may take a while to show the commands; guild registration is much faster.

## Notes

- Finn's first cry happens 30 minutes after the bot starts.
- After someone cares for him, the next crying episode is scheduled for 30 minutes later.
- While crying, he sends a message once per minute until cared for. This is intentionally limited so one forgotten baby does not flood the channel.
- His crying state is kept in memory, so restarting the bot resets the timer.
- Never commit your `.env` file or share your bot token.
